CSS NYAN CAT
========

#### Pure CSS Mem ####

CSS NYAN CAT was created by [Michał Budzyński](http://twitter.com/michalbe) for [Mozilla Demo Party](http://mozillalabs.com/demoparty/helsinki) in Helsinki on 18.06.2011.


It contains **81 DOM elements**, **688 lines of pure CSS** and **one JavaScript function** for
looping audio. My CSS **fails** CSSLint test and I'm really proud of this. See you on [onGameStart, first HTMl5 game conference ever](http://ongamestart.com/)!
